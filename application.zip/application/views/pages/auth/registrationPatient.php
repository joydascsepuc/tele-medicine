<?php echo form_open('patientregister');?>
	<div class="container-fluid mt-5" style="">
		<div class="row">
			<div class="col-sm-3"></div>
			<div class="col-sm-6" style="border: 2px dotted black; padding: 2rem 2rem 3rem 2rem; border-radius: 10px;">

				<div class="row mb-2">
					<div class="col-sm-4"></div>
					<div class="col-sm-4 text-center">
						<i class="fas fa-school fa-3x"></i>
					</div>
					<div class="col-sm-4"></div>
				</div>
				<h3 class="text-center mb-3 ">Patient Register Form</h3>
				<div class="row mb-2 text-center">
					<font color="red"><?php echo validation_errors(); ?></font>
					<font color="green">
						<?php if(!empty($success)) {
					      echo $success;
					    } ?>
					</font>
					<font color="red">

					    <?php if(!empty($errors)) {
					      echo $errors;
					    } ?>
					</font>
				</div>
					
				<!-- <select class="form-control mb-2 mt-2" id="registerType" name="registerType" required style="height:35px !important;">
					<option selected value="">Register Type</option>
					<option value="1">Doctor</option>
					<option value="2">Patient</option>
				</select>-->

				<input type="text" autocomplete="off" name="name" id="name" class="form-control" placeholder="@Your Full Name" style="height:35px !important;" required autofocus>

				<input type="text" autocomplete="off" name="navyID" id="navyID" class="form-control mb-2 mt-2" placeholder="@Your Navy ID (Only Navy ID)" style="height:35px !important;" required>

				<div class="row mb-2 mt-2">
					<div class="col-6">
						<!-- <label for="category">Type/Category</label> -->
						<select required class="form-control select_group" id="category" name="category">
                          <option value="" selected>Type/Category</option>
                          <?php foreach ($category as $k => $v): ?>
                            <option value="<?php echo $v['id'] ?>"><?php echo $v['name'] ?></option>
                          <?php endforeach ?>
                        </select>
					    
					</div>
					<div class="col-6">
						<!-- <label for="rank">Rank</label> -->
					    <select required class="form-control select_group" id="rank" name="rank">
                          <option value="" selected>Rank</option>
                          <?php foreach ($rank as $k => $v): ?>
                            <option value="<?php echo $v['id'] ?>"><?php echo $v['name'] ?></option>
                          <?php endforeach ?>
                        </select>
					</div>
				</div>
				<div class="row mb-2 mt-2">
					<div class="col-6">
						<select required class="form-control select_group" id="relation" name="relation">
                          <option value="" selected>Relation</option>
                          <?php foreach ($relation as $k => $v): ?>
                            <option value="<?php echo $v['id'] ?>"><?php echo $v['name'] ?></option>
                          <?php endforeach ?>
                        </select>
					</div>
					<div class="col-6">
						<!-- <label for="gender">Gender</label> -->
					    <select class="form-control" id="gender" name="gender" required>
					      <option selected value="">Gender</option>
					      <option value="1">Male</option>
					      <option value="2">Female</option>
					      <option value="3">Other</option>
					    </select>
					</div>
				</div>
				<div class="row mb-2 mt-2">
					<div class="col-6 pmId1">
                        <span class="input-group-addon pmId2" style="display:none;"></span>
						<input type="text" autocomplete="off" name="mobile" id="mobile" class="form-control" placeholder="@Mobile No" style="height:35px !important;" required minlength="11" maxlength="11" pattern="\d*">
						<!-- <p class="help-block pName"></p> -->
					</div>
					<div class="col-6">
						<input type="number" autocomplete="off" name="age" min="1" class="form-control" placeholder="@Age" style="height:35px !important;" required>
					</div>
				</div>
				<div class="row mb-2 mt-2">
					<div class="col-6">
						<input type="mail" autocomplete="off" name="mail" class="form-control" placeholder="@email" style="height:35px !important;">
					</div>
					<div class="col-6">
						<input type="password" autocomplete="off" name="password" class="form-control" placeholder="@Password" minlength="6" maxlength="12" style="height:35px !important;" required>
					</div>
				</div>
				<textarea class="form-control" id="address" name="address" placeholder="@Address" style="height: 100px;"></textarea>
				
				<div class="row mb-1">
					<div class="col-2"></div>
					<div class="col-8">
						<button id="submitButton" class="btn btn-outline-secondary font-weight-bold btn-block mt-2" style="color: black;">Register&nbsp;<i class="fas fa-sign-in-alt"></i></button>
					</div>
					<div class="col-2"></div>
				</div>
			</div>
			<div class="col-3"></div>
		</div>
	</div>
<!-- </form> -->


<!-- <script type="text/javascript">
var base_url = "<?php echo base_url(); ?>";

	$('#registerType').on('change', function(){
	    var registerType = $(this).val();
	    if(registerType == "1")
	    {
	        $('#banks').prop('disabled', false);
	            bank.style.visibility='visible';
	            bank.style.display='initial';
	              // check.style.visibility='visible';
	              // check.style.display='initial';
	   	}
	    else {
	        $('#banks').prop('disabled', true);
	        bank.style.visibility='hidden';
	        bank.style.display='none';
	        // check.style.visibility='hidden';
	        // check.style.display='none';
	    }

	});

</script>-->


<script type="text/javascript">
	var base_url = "<?php echo base_url(); ?>";
	$(document).ready(function() {
    	$(".select_group").select2();
    });


    $(document).on('focus', '.select2', function (e) {
    if (e.originalEvent) {
	        var s2element = $(this).siblings('select');
	        s2element.select2('open');
	        // Set focus back to select2 element on closing.
	        s2element.on('select2:closing', function (e) {
	            s2element.select2('focus');
	       });
    	}
	});

    $("#mobile").keyup('on',function(){

	  var mobile = $("#mobile").val();

	  if(mobile != ''){
	    $('.pmId1').addClass('input-group');
	    $('.pmId2').show();
	    $('.pmId2').html('<img style="height: 20px;" src="<?=base_url('assets/images/ajax-loader.gif');?>">');
	    $.ajax({
	      dataType : "json",
	       url:base_url + 'userphone',
	       method:"POST",
	       //dataType: "json",
	      data:{mobile:mobile},
	       success:function(data)
	       {
	         if(data.status == 1)

	                {
	                  //alert('Member Id verified : '+data.json_ar['name']); '+data.json_ar['name']+'
	                 // $('.pName').html('<span style="color:red;">Phone Number is Registered with : '+data.json_ar['name']+'</span>');

	                  $('.pmId2').html('<img style="height: 20px;" src="<?=base_url('assets/images/cross_mark.jpg');?>">');
	                  $("#submitButton").attr("disabled", true);
	                  }else{

	                  // $('.pName').html('<span style="color:green;">Phone Number is Available</span>'); 

	                  $('.pmId2').html('<img style="height: 20px;" src="<?=base_url('assets/images/green_checkmark.jpg');?>">');
	                  $("#submitButton").attr("disabled", false);

	                }
	       },

	       error: function (jqXHR, status, err) {

	             // alert("Local error callback.");

	            }
	      });
	  }else{

	    $('.pmId1').removeClass('input-group');

	    $('.pmId2').hide();

	    // $('.mName').html(''); 

	  }
	});


</script>
