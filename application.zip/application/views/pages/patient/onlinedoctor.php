<div class="container mt-3">
	<div class="row">
		<div class="col-12">
			<!-- Suru -->
			<?php if ($availableDoctor): ?>
			<?php foreach ($availableDoctor as $key => $value): ?>
			<h4 class="mb-3 text-center">Available Doctors at <?=$department['name']?></h4>
			<div style="max-height: 80px; overflow-y: hidden; overflow-x: hidden;" class="mb-2 mt-1">
					<div class="row">
						<div class="col-sm-1"></div>
						<div class="col-sm-10">
							<div class="row">
								<div class="col-1">
									<i class="fas fa-user-md fa-2x"></i>
								</div>
								<div class="col-8">
									<span class="font-weight-bold" style="color:black; vertical-align: middle;"><?=$value['users']['name']?></span><br>
								</div>
								<div class="col-3">
									<a href="tel:<?=$value['usersdetails']['emContact']?>" class="btn btn-success">Call&nbsp;<i class="fa fa-mobile-alt"></i></a>
									<a href="<?php echo base_url()?>.patient/placeserial/<?=$value['users']['id']?>/<?=$department['id']?>" class="btn btn-primary">Place Serial&nbsp;<i class="fas fa-list-ol"></i></a>
								</div>
							</div>
							<span class="" style="overflow-y: hidden;"><?=$value['usersdetails']['qualification']?>, <?=$value['usersdetails']['designation']?>, <?=$value['usersdetails']['speciality']?></span>
						</div>
						<div class="col-sm-1"></div>
					</div>
			</div>
		
		<?php endforeach ?>
		<?php else:?>
			<h4 class="mb-3 text-center">No Available Doctors at <?=$department['name']?></h4>
		<?php endif ?>
		
			
			
			

		</div>
	</div>
</div>