<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat extends Admin_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		//$this->data['page_title'] = 'Patient';
	}

	public function index($appoinmentID){
		$this->data['appoinments'] = $appoinments = $this->model_doctors->getAllAppontmentData($appoinmentID);
		$this->data['department'] = $this->model_department->getDepartmentData($appoinments['departmentID']);
		if ($this->session->userdata('group')==4) {
			
			$this->data['receiver']=   $this->model_doctors->getDoctorFullDetails($appoinments['doctorID']);
		}
		elseif ($this->session->userdata('group')==3) {
			$this->data['receiver']=   $this->model_patient->getPatientFullDetails($appoinments['pateintID']);
		}

		$this->render_template('pages/chat/chatpage' , $this->data);
	}


	public function fetchChatHistory($recvrID)
	{	
		$loggedINUser = $this->session->userdata('id');
		$html='';
		$chathistory = $this->model_chat->getReceiverChatHistory($recvrID);

		foreach ($chathistory as $key => $value) {
			$this->db->where('id', $value['id']);
			$this->db->update('chat', array('seen' => 1));

			if($value['sender_id'] == $recvrID){
				if($value['message'] != 'NULL'){
					$html.='<div class="mt-2" style="border: 1px solid black; float: left; width: 75%;padding: 5px; text-align: left; border-radius: 0px 15px 15px 15px">
									'.$value['message'].'
									<br><span style="float: right;">'.date('d/m/y h:i a', $value['message_date_time']).'</span>
								</div>';
				}
				else{
					$attachment_name = $value['attachment_name'];
					$file_ext = $value['file_ext'];
					$mime_type = explode('/',$value['mime_type']);
					$document_url = base_url().$value['attachment_path'];
							
					if($mime_type[0]=='image'){
						$html.= '<img style="float: left" src="'.$document_url.'" onClick="ViewAttachmentImage('."'".$document_url."'".','."'".$attachment_name."'".');" class="attachmentImgCls mt-2">';
					}
					else{
						$html.= '<div class="mt-2" style="border: 1px solid black; float: left; width: 75%;padding: 5px; text-align: left; border-radius: 0px 15px 15px 15px">
								<h4>Attachments:</h4>
								<p class="filename">'.$attachment_name.'</p>
								<a download href="'.$document_url.'"><button type="button" id="'.$value['id'].'" class="btn btn-primary btn-sm btn-flat btnFileOpen">Open</button></a>
								<br><span style="float: right;">'.date('d/m/y h:i a', $value['message_date_time']).'</span>
							</div>';
					}
				}
			}
			else{
				if($value['message'] != 'NULL'){
					$html.='<div class="mt-2" style="border: 1px solid black; width: 75%; float: right; padding: 5px; text-align: left; border-radius: 15px 0px 15px 15px">
						'.$value['message'].'
						<br><span style="float: right;">'.date('d/m/y h:i a', $value['message_date_time']).'</span>
					</div>';
				}
				else{
					$attachment_name = $value['attachment_name'];
					$file_ext = $value['file_ext'];
					$mime_type = explode('/',$value['mime_type']);
					$document_url = base_url().$value['attachment_path'];
					
					if($mime_type[0]=='image'){
						$html.='<img  style="float: right" src="'.$document_url.'" onClick="ViewAttachmentImage('."'".$document_url."'".','."'".$attachment_name."'".');" class="attachmentImgCls mt-2">';
					}
					else{
						$html.= '<div class="mt-2" style="border: 1px solid black; float: right; width: 75%;padding: 5px; text-align: left; border-radius: 15px 0px 15px 15px">
								<h4>Attachments:</h4>
								<p class="filename">'.$attachment_name.'</p>
								<a download href="'.$document_url.'"><button type="button" id="'.$value['id'].'" class="btn btn-primary btn-sm btn-flat btnFileOpen">Open</button></a>
								<br><span style="float: right;">'.date('d/m/y h:i a', $value['message_date_time']).'</span>
							</div>';
					}
				}
			}
		}

		echo($html);
	}



	public function send_text_message(){
		$post = $this->input->post();
		$messageTxt='NULL';
		$attachment_name='';
		$file_ext='';
		$mime_type='';
		$path='';
		if(isset($post['type'])=='Attachment'){ 
		 	$AttachmentData = $this->ChatAttachmentUpload();
			//print_r($AttachmentData);
			$attachment_name = $AttachmentData['file_name'];
			$file_ext = $AttachmentData['file_ext'];
			$mime_type = $AttachmentData['file_type'];
			$path = 'assets/attachment/'.$AttachmentData['file_name'];
			 
		}else{
			$messageTxt = reduce_multiples($post['messageTxt'],' ');
		}	
		 
				$data=[
 					'sender_id' => $this->session->userdata['id'],
					'receiver_id' => $post['receiver_id'],
					'message' =>   $messageTxt,
					'attachment_name' => $attachment_name,
					'attachment_path' => $path,
					'file_ext' => $file_ext,
					'mime_type' => $mime_type,
					'message_date_time' => strtotime(date('Y-m-d h:i:s a')), //23 Jan 2:05 pm
					'ip_address' => $this->input->ip_address(),
					'appointmentID' => $post['appointID'],
				];
		  
 				$query = $this->model_chat->SendTxtMessage($data); 
 				$response='';
				if($query == true){
					$response = ['status' => 1 ,'message' => '' ];
				}else{
					$response = ['status' => 0 ,'message' => 'sorry we re having some technical problems. please try again !' 						];
				}
             
 		   echo json_encode($response);
	}


	public function ChatAttachmentUpload(){
		 
		
		$file_data='';
		if(isset($_FILES['attachmentfile']['name']) && !empty($_FILES['attachmentfile']['name'])){	
				$config['upload_path']          = 'assets/attachment';
				$config['allowed_types']        = 'jpeg|jpg|png|txt|pdf|docx|xlsx|pptx|rtf';
        		
				$this->load->library('upload', $config);
				if ( ! $this->upload->do_upload('attachmentfile'))
				{
					echo json_encode(['status' => 0,
					'message' => '<span style="color:#900;">'.$this->upload->display_errors(). '<span>' ]); die;
				}
				else
				{
					$file_data = $this->upload->data();
					//$filePath = $file_data['file_name'];
					return $file_data;
				}
		    }
 		 
	}


}