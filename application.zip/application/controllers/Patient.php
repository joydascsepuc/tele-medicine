<?php

class Patient extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->not_logged_in();

		$this->data['page_title'] = 'Patient';
	}

	public function home()
	{
		// // if(!in_array('viewPatient', $this->permission)) {
		// // 	redirect('dashboard', 'refresh');
		// // }
		// $appointments = $this->model_patient->getAppontmentDataByPatient($this->session->userdata('id'));
		// $result = array();
		// foreach ($appointments as $key => $value) {
		// 		$result[$key]['apoint'] = $value; 
		// 		$result[$key]['doctor'] = $this->model_doctors->getDoctorFullDetails($value['doctorID']);
		// 		$result[$key]['department'] = $this->model_department->getDepartmentData($value['departmentID']);
		// 	}

		// $this->data['appoinments'] = $result;
		$this->render_template('pages/patient/index', $this->data);
	}


	public function takeappointment()
	{
		// if(!in_array('viewPatient', $this->permission)) {
		// 	redirect('dashboard', 'refresh');
		// }
		$this->data['department'] = $this->model_department->getActiveDepartment();
		$this->render_template('pages/patient/takeappointment', $this->data);
	}


	public function doctorOnline($deptID)
	{
		// if(!in_array('viewPatient', $this->permission)) {
		// 	redirect('dashboard', 'refresh');
		// }
		$result = array();
		if ($deptID) {
			$onlineDoctor = $this->model_department->doctorOnline($deptID);

			foreach ($onlineDoctor as $key => $value) {
				$result[$key]['users'] = $this->model_users->getUserData($value['id']);
				$result[$key]['usersdetails'] = $this->model_doctors->getDoctorbyUser($value['id']);
			}
			$this->data['availableDoctor'] = $result;
			$this->data['department'] = $this->model_department->getDepartmentData($deptID);
			$this->render_template('pages/patient/onlinedoctor', $this->data);
		}
		
	}


	public function placeserial($docID, $deptID)
	{
		if ($docID && $deptID) {
		$this->form_validation->set_rules('complaint', 'Complaint', 'required');

	      if ($this->form_validation->run() == TRUE) {

				$placed = $this->model_patient->placeserial($docID, $deptID);
				if($placed != false) {
					$this->session->set_flashdata('success', 'Successfully Placed. Your Serial is '.$placed);
        			redirect('patienthome', 'refresh');
        		}
        		else {
	        		$this->session->set_flashdata('errors', 'Error Occurred!!');
	        		redirect('placeserial/'.$docID.'/'.$deptID, 'refresh');
	        	}
	        }
	        else {
				$this->data['department'] = $this->model_department->getDepartmentData($deptID);
				$this->data['doctor'] = $this->model_users->getUserData($docID);
				$this->data['doctordetails'] = $this->model_doctors->getDoctorbyUser($docID);
				$this->render_template('pages/patient/placeserial', $this->data);
	        }
		}
	}


	public function appoinmentdetails($id)
	{
		if ($id) {
        		
				$this->data['appoinments'] = $appoinments = $this->model_doctors->getAllAppontmentData($id);
				$this->data['department'] = $this->model_department->getDepartmentData($appoinments['departmentID']);
				$this->data['prescription'] =$pres= $this->model_patient->getPrescriptionByAppointment($appoinments['id']);
				$this->data['prescriptionMedicines'] = $this->model_patient->getPrescriptionMedicinesByAppointment($pres['id']);
				$this->data['doctor'] = $this->model_doctors->getDoctorFullDetails($appoinments['doctorID']);
				$this->data['unseen']= $this->model_chat->getUnseenMessagesByAppointment($appoinments['doctorID'], $appoinments['id']);
			    $this->render_template('pages/patient/appoinmentdetails' , $this->data);
        	}
	}



	public function fetchAppointmentList()
	{
		$appointments = $this->model_patient->getAppontmentDataByPatient($this->session->userdata('id'));
		$html = ''; 
		$currentDate = strtotime(date('Y-m-d'));
		
		foreach ($appointments as $key => $value) {
			$color = ''; 
			$url ='';
			$doctor = $this->model_doctors->getDoctorFullDetails($value['doctorID']);
			$department = $this->model_department->getDepartmentData($value['departmentID']);
			if ($value['visited']==1 && $value['called']==1) {
				$color = 'green';
				$url ='<a href="'.base_url('patappoinmentdetails/'.$value['id']).'" style="color: black; text-decoration: none;">';

			}
			elseif ($value['visited']==0 && $value['called']==1) {
				$color = 'blue';
				$url ='<a href="'.base_url('patappoinmentdetails/'.$value['id']).'" style="color: black; text-decoration: none;">';
			}
			else{
				if ($value['datetime'] >= $currentDate) {
					$color = 'red';
					$url ='<a onclick="alertFunction1()" href="#" style="color: black; text-decoration: none;">';
				}
				else{
					$color = 'none'; 
					$url ='<a onclick="alertFunction2();" href="#" style="color: black; text-decoration: none;">';
				}
			}


			$html.='<div style="max-height: 100px; overflow-y: hidden; overflow-x: hidden; background-color:'.$color.';" class="mb-2 mt-1">
				';
			$html .= $url;
			$html .= '<div class="row">
						<div class="col-sm-1"></div>
						<div class="col-sm-10">
							<div class="row">
								<div class="col-1">
									<i class="fas fa-user-circle fa-2x"></i>
								</div>
								<div class="col-9">
									<span class="font-weight-bold" style="vertical-align: middle;">'.$department['name'].'</span><br>
								</div>
								<div class="col-2">
									<span class="font-weight-bold">'.date('d/m/y h:i a', $value['datetime']).'</span>
								</div>
							</div>
						</div>
						<div class="col-sm-1"></div>
					</div>
				</a>
			</div>';
			

		}
		echo ($html);
	}
        

	public function pdfPrescription($id)
	{
		
		$appointments = $this->model_doctors->getAllAppontmentData($id);
		$pres= $this->model_patient->getPrescriptionByAppointment($appointments['id']);
		$prescriptionMedicines= $this->model_patient->getPrescriptionMedicinesByAppointment($pres['id']);
		$department = $this->model_department->getDepartmentData($appointments['departmentID']);
		$doctor= $this->model_doctors->getDoctorFullDetails($appointments['doctorID']);
		$patient= $this->model_patient->getPatientFullDetails($appointments['pateintID']);
		$relationship =  $this->model_patient->getRelationshipData($patient['prelation']);
		$rank =  $this->model_patient->getRankData($patient['prank']);
		$category =  $this->model_patient->getCategoryData($patient['pcategory']);

		$html = '<!-- Main content -->
		<!DOCTYPE html>
		<html>
		<style>
		.single-report h5 {
		  font-weight: 700;
		}
		.single-report {
		  margin-bottom: 20px;
		  border-bottom: 1px solid #ddd;
		  border-right: 1px solid #ddd;
		}
		body {
						height: auto;
					}
		table {
		  width: 100%;
		}
		/*.margin-15{
		  margin: 0 -15px;
		  margin-top: -10px;
		}*/
		.width-10 {
		  width: 10%;
		}
		.width-40 {
		  width: 40%;
		}.width-15 {
		  width: 15%;
		}
		.width-70 {
		  width: 70%;
		}
		tr {
		  border: 1px solid #ddd;
		}

		td {
		  float: left;
		}
		.single-madicine {
		  padding: 0 10px;
		}
		.single-report {
		  padding: 0 5px;
		}

		.border-right {
		  border-radius: ;
		  border-right: 1px solid #ddd;
		}
		.single-madicine p {
		  margin-bottom: ;
		  margin-top: 0 !important;
		 /* text-align: center;*/
		}
		.single-madicine h5 {
		  margin-bottom: 2px;
		}
		.single-madicine {
		  margin-left: 20px;
		}
		.rx {
		  padding: 0 5px;
		}
		.rx h2 {
		  position: relative;
		  margin-top: 5px;
		}
		.rx h2 span {
		  position: absolute;
		  left: 11px;
		  bottom: -9px;
		  font-size: 20px;
		  font-weight: 900;
		  color: #ddd;
		  z-index: 5;
		}

		.width-30 {
		  width: 30%;
		  float: left;
		}
		.width-20 {
		  width: 20%;
		  float: left;
		}

		.width-50 {
		  width: 50%;
		  float: left;
		}
		.width-25 {
		  width: 25%;
		  float: left;
		}
		.width-70{
		  padding: 2px
		}

		.width-45 {
		  width: 45% !important;
		  float: left;
		  
		}
		.width-5 {
		  width: 5% !important;
		  float: left;
		  
		}
		.width-5 {
				  width: 5%;
				  float: left;
				}
				.width-95 {
				  width: 95%;
				  float: left;
				}
		.custom-style {
		  padding: ;
		  margin-top: 5px;
		}
		.width-70 th, .width-70 td {
		  border: none;
		 padding: 3px;
		 float: left;
	     padding: 3px;
		}

		

		.dv-nv {
			  margin-top: 40px;
			}
			.width-12 {
			  width: 12%;
			  text-align:center;
			}

			.height-30 {
			  height: : 30%;
			  text-align: : center;
			  
			}
		</style>
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<title>Prescription Print</title>
			<!-- Tell the browser to be responsive to screen width -->
			<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			<!-- Bootstrap 3.3.7 -->
			<link rel="stylesheet" href="'.base_url('assets/bower_components/bootstrap/dist/css/bootstrap.min.css').'">
			<!-- Font Awesome -->
			<link rel="stylesheet" href="'.base_url('assets/bower_components/font-awesome/css/font-awesome.min.css').'">
			<link rel="stylesheet" href="'.base_url('assets/dist/css/AdminLTE.min.css').'">
		</head>

		<body >
<div id="example" >
		<div class="wrapper">
			<section class="invoice">
				<!-- title row -->
				<div class="row">
				
					<div class="col-xs-12">
					<text style="font-size: 8pt;" class="pull-right"></text><br>
						<h2 class="page-header">
							BNS Patenga 
							<font align="right">Print Date: '.date('d/m/y h:i:s a').'</font>
						<br>
					
						</h2>
					</div>
					<!-- /.col -->

				<!-- info row -->
				<div class="col-xs-12">
					'.$this->Barcode($pres['code']).'<br>
			        '.$pres['code'].'
					<br>
					<b>Pateint UNID: </b> '.$patient['patientID'].'
					&nbsp<b>Pateint Name: </b> '.$patient['name'].'
					&nbsp<b>Age: </b> '.$patient['age'].'
					&nbsp<b>Navy ID: </b> '.$patient['navyID'].'
					&nbsp<b>Category/Rank/Relation: </b>'.$category['name'].'/'.$rank['name'].'/'.$relationship['name'].'
					&nbsp<b>Disease: </b> '.$pres['disease'].'
					&nbsp<b>Checkup Date: </b> '.date('d/m/Y h:i a', $pres['dateTime']).'
				</div>

					<!-- /.col -->
				</div>


				<!-- /.row -->
				<!-- Table row -->
				<div class="row">
				<div class="box-body table table-responsive">
					<table>
						<h4 align="center"><b> Prescription</b></h4>
						<thead>
						</thead>
						<tbody><tr>
							<td class="width-30 border-right">
									<div class="single-report">';

									$html.='<h5>Chief Complaints: </h5>
										'.$pres['complaint'].'

									</div>

									<div class="single-report">
										<h5>Exmination Finding: </h5>
										'.$pres['examination'].'

									</div>
									<div class="single-report">
										<h5>Investigation: </h5>
										'.$pres['diagnosis'].'

										</div>
									<div class="single-report">
										<h5>Clicnical Diagnosis: </h5>
										'.$pres['investigation'].'

										</div>
									<div class="single-report">
										<h5>Advice: </h5>
										'.$pres['advice'].'

										</div>';
							$html.='</td>
							<td class="width-70">
								<div class="rx">
									<h2>R <span>X</span></h2>
								</div>
								
									';
										foreach ($prescriptionMedicines as $key => $value){
											$instruction=($value['instruction']!='')?$value['instruction'].', ':'';
								            $instruction2=($value['instruction2']!='')?$value['instruction2'].', ':'';
								            $day=($value['day']!='')?$value['day'].', ':'';
											$count=$key+1;
										$html .= '

											<li class="ml-2">
					                          '.$value['medicine'].'&nbsp;&nbsp;|&nbsp;&nbsp;'.$value['instruction'].'&nbsp;&nbsp;|&nbsp;&nbsp;'.$value['instruction2'].'&nbsp;&nbsp;|&nbsp;&nbsp;'.$value['day'].'&nbsp;&nbsp;|&nbsp;&nbsp;'.$value['amount'].'
					                        </li>
										';

									}
								$html .= '';
								
							$html .= '</td>

							</tr>
						</tbody>

					</table>
					<div style="text-align:right" class="col-sm-12 invoice-col pull pull-right">
						<img src="'. base_url($doctor['signature_image']) .'" width="200" height="30"/><br>
						<b>'.$doctor['name'].'</b>, '.$doctor['qualification'].', '.$doctor['designation'].', '.$doctor['phone'].'
					</div>

				</div>
					<!-- /.col -->
				</div>
				<!-- /.row -->
			</section>
			<!-- /.content -->
			</div>
			</div>
		</div>
	</body>
</html>';
	

		$this->dompdf->loadHtml($html);
		$this->dompdf->setPaper('A4', 'potrait');
		$this->dompdf->render();
		//$this->dompdf->output("".$patient['name'].$pres['code'].".pdf", "D");
		$this->dompdf->stream("".$patient['name'].$pres['code'].".pdf", array("Attachment"=>0));
	}



	public function Barcode($value)
	{
		require "vendor/autoload.php";
		//$generator = new Picqer\Barcode\BarcodeGeneratorHTML();
		// $code= $generator->getBarcode($value, $generator::TYPE_CODE_128);
		$generator = new \Picqer\Barcode\BarcodeGeneratorPNG();
		return '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode($value, $generator::TYPE_CODE_128)) . '">';

		// return $code;
	}


}
